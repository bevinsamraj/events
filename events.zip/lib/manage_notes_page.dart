import 'dart:convert';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:cloudinary_public/cloudinary_public.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart' hide PlayerState;
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

void main() {
  runApp(MaterialApp(
    home: ManageNotesPage(),
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      primaryColor: const Color(0xFF0B1957),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF0B1957),
        elevation: 4,
      ),
      scaffoldBackgroundColor: const Color(0xFFD1E8FF),
      textTheme: GoogleFonts.poppinsTextTheme(),
    ),
  ));
}

class ManageNotesPage extends StatefulWidget {
  @override
  _ManageNotesPageState createState() => _ManageNotesPageState();
}

class _ManageNotesPageState extends State<ManageNotesPage> {
  List<dynamic> notes = [];
  bool isLoading = true;
  String errorMsg = '';
  String searchQuery = '';
  final String notesApiUrl = 'https://demo.yelbee.com/events/manage_notes.php';

  @override
  void initState() {
    super.initState();
    fetchNotes();
  }

  Future<void> fetchNotes() async {
    setState(() {
      isLoading = true;
      errorMsg = '';
    });
    try {
      final response = await http.get(Uri.parse('$notesApiUrl?action=list'));
      if (response.statusCode == 200) {
        final decodedData = jsonDecode(response.body);
        if (decodedData is Map && decodedData['data'] is List) {
          setState(() {
            notes = decodedData['data'];
            isLoading = false;
          });
        } else if (decodedData is List) {
          setState(() {
            notes = decodedData;
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
            errorMsg = "Notes data is either null or not a list";
          });
        }
      } else {
        setState(() {
          isLoading = false;
          errorMsg = "Failed to load data: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        errorMsg = "Error fetching data: $e";
      });
    }
  }

  Map<String, List<dynamic>> groupNotesByEvent() {
    Map<String, List<dynamic>> grouped = {};
    for (var note in notes) {
      final eventId = note['event_id'].toString();
      if (!grouped.containsKey(eventId)) {
        grouped[eventId] = [];
      }
      grouped[eventId]!.add(note);
    }
    return grouped;
  }

  @override
  Widget build(BuildContext context) {
    final grouped = groupNotesByEvent();
    // Apply search filtering based on event name.
    final filteredKeys = grouped.keys.where((key) {
      final eventName = grouped[key]!.first['event_name'] ?? 'Unnamed Event';
      return eventName.toLowerCase().contains(searchQuery.toLowerCase());
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Manage Notes',
          style: GoogleFonts.poppins(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : errorMsg.isNotEmpty
              ? Center(
                  child: Text(errorMsg,
                      style:
                          GoogleFonts.poppins(color: Colors.red, fontSize: 16)))
              : RefreshIndicator(
                  onRefresh: fetchNotes,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(12),
                    children: [
                      Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 6,
                                offset: const Offset(0, 2))
                          ],
                        ),
                        child: TextField(
                          onChanged: (value) {
                            setState(() {
                              searchQuery = value;
                            });
                          },
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: 'Search events...',
                            icon: Icon(Icons.search, color: Colors.grey[600]),
                          ),
                        ),
                      ),
                      filteredKeys.isEmpty
                          ? Center(
                              child: Padding(
                                padding: const EdgeInsets.only(top: 40),
                                child: Text("No notes available",
                                    style: GoogleFonts.poppins(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500)),
                              ),
                            )
                          : ListView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: filteredKeys.length,
                              itemBuilder: (context, index) {
                                String eventId = filteredKeys[index];
                                List<dynamic> eventNotes = grouped[eventId]!;
                                String eventName =
                                    eventNotes.first['event_name'] ??
                                        'Unnamed Event';
                                return Card(
                                  margin: const EdgeInsets.symmetric(
                                      vertical: 8, horizontal: 4),
                                  elevation: 4,
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(16)),
                                  child: ListTile(
                                    contentPadding: const EdgeInsets.all(16),
                                    leading: CircleAvatar(
                                      backgroundColor: const Color(0xFF0B1957),
                                      child: Text(
                                        eventName.substring(0, 1),
                                        style: GoogleFonts.poppins(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                    title: Text(
                                      eventName,
                                      style: GoogleFonts.poppins(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    subtitle: Text(
                                        "Notes: ${eventNotes.length}",
                                        style: GoogleFonts.poppins()),
                                    trailing: Icon(Icons.arrow_forward_ios,
                                        color: Colors.grey[600]),
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => NoteDetailsPage(
                                            eventId: eventId,
                                            eventName: eventName,
                                            notes: eventNotes,
                                          ),
                                        ),
                                      ).then((_) {
                                        // When coming back, navigate to home page.
                                        Navigator.popUntil(
                                            context, (route) => route.isFirst);
                                      });
                                    },
                                  ),
                                );
                              },
                            )
                    ],
                  ),
                ),
    );
  }
}

class NoteDetailsPage extends StatefulWidget {
  final String eventId;
  final String eventName;
  final List<dynamic> notes;
  NoteDetailsPage(
      {required this.eventId, required this.eventName, required this.notes});

  @override
  _NoteDetailsPageState createState() => _NoteDetailsPageState();
}

class _NoteDetailsPageState extends State<NoteDetailsPage> {
  Map<String, dynamic> eventDetails = {};
  List<dynamic> notes = [];
  bool isLoading = true;
  final String eventsApiUrl =
      'https://demo.yelbee.com/events/manage_events.php';
  final String notesApiUrl = 'https://demo.yelbee.com/events/manage_notes.php';
  final AudioPlayer _audioPlayer = AudioPlayer();

  @override
  void initState() {
    super.initState();
    notes = List.from(widget.notes);
    fetchEventDetails();
  }

  Future<void> fetchEventDetails() async {
    try {
      final response = await http.get(Uri.parse(
          '$eventsApiUrl?action=get_event_details&event_id=${widget.eventId}'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true && data['event'] != null) {
          setState(() {
            eventDetails = data['event'];
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
            eventDetails = widget.notes.first;
          });
        }
      } else {
        setState(() {
          isLoading = false;
          eventDetails = widget.notes.first;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        eventDetails = widget.notes.first;
      });
    }
  }

  Future<void> _editNote(Map<String, dynamic> note) async {
    if (note['note_status'] == "off") return;
    final updated = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => EditNotePage(note: note)),
    );
    if (updated == true) {
      setState(() {});
    }
  }

  Future<void> _deleteNote(Map<String, dynamic> note) async {
    setState(() {
      isLoading = true;
    });
    final noteId = note['note_id'].toString();
    try {
      final response =
          await http.delete(Uri.parse('$notesApiUrl?action=delete&id=$noteId'));
      final data = jsonDecode(response.body);
      if (data['success'] == true) {
        setState(() {
          for (var n in notes) {
            if (n['note_id'].toString() == noteId) {
              n['note_status'] = "off";
              break;
            }
          }
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['error'] ?? 'Failed to delete.')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  String _formatDate(String dateStr) {
    try {
      final dt = DateTime.parse(dateStr);
      return DateFormat('dd-MM-yyyy').format(dt);
    } catch (_) {
      return dateStr;
    }
  }

  Widget _buildEventDetailRow(IconData icon, String text) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: Colors.blue),
        const SizedBox(width: 8),
        Expanded(
          child: Text(text, style: GoogleFonts.poppins(fontSize: 16)),
        ),
      ],
    );
  }

  Widget _buildEventDetailsCard() {
    final eventData =
        eventDetails.isNotEmpty ? eventDetails : widget.notes.first;
    return Card(
      elevation: 6,
      margin: const EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue.shade50, Colors.blue.shade100],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Event Details",
                style: GoogleFonts.poppins(
                    fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            _buildEventDetailRow(
                Icons.event, eventData['event_name'] ?? widget.eventName),
            const SizedBox(height: 12),
            _buildEventDetailRow(Icons.calendar_today,
                "Date: ${_formatDate(eventData['start_date'] ?? '')} - ${_formatDate(eventData['end_date'] ?? '')}"),
            const SizedBox(height: 12),
            _buildEventDetailRow(
                Icons.location_on, "Venue: ${eventData['venue'] ?? 'N/A'}"),
            const SizedBox(height: 12),
            _buildEventDetailRow(
                Icons.place, "City: ${eventData['city'] ?? 'N/A'}"),
            const SizedBox(height: 12),
            _buildEventDetailRow(Icons.phone,
                "Contact: ${eventData['contact_name'] ?? 'N/A'} | ${eventData['contact_number'] ?? 'N/A'}"),
            const SizedBox(height: 12),
            _buildEventDetailRow(
                Icons.info, "Type: ${eventData['event_type'] ?? 'N/A'}"),
            const SizedBox(height: 12),
            _buildEventDetailRow(
                Icons.label, "Tags: ${eventData['tags'] ?? 'N/A'}"),
          ],
        ),
      ),
    );
  }

  Widget _buildNoteCard(Map<String, dynamic> note) {
    final title = note['title'] ?? 'No Title';
    final sessionTime = note['session_time'] ?? 'No Session Time';
    final noteContent = note['notes'] ?? 'No Content';
    final audioUrl = note['audio'] ?? '';
    final createdDate = note['note_created_date'] ?? 'No Date';
    final isDeleted = (note['note_status'] ?? "on") == "off";

    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: isDeleted ? Colors.grey.shade300 : Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(title,
                      style: GoogleFonts.poppins(
                          fontSize: 18, fontWeight: FontWeight.bold)),
                ),
                if (isDeleted)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.red.shade400,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      "Deleted",
                      style: GoogleFonts.poppins(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Text("Session: $sessionTime",
                style:
                    GoogleFonts.poppins(fontSize: 14, color: Colors.grey[700])),
            const SizedBox(height: 8),
            Text(noteContent,
                style: GoogleFonts.poppins(fontSize: 15),
                textAlign: TextAlign.justify),
            const SizedBox(height: 8),
            if (audioUrl.isNotEmpty)
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("Audio:", style: GoogleFonts.poppins(fontSize: 14)),
                  const SizedBox(width: 8),
                  AudioPlayerWidget(audioUrl: audioUrl),
                ],
              ),
            const SizedBox(height: 8),
            Text("Created: ${_formatDate(createdDate)}",
                style:
                    GoogleFonts.poppins(fontSize: 12, color: Colors.grey[600])),
            const Divider(height: 24),
            if (!isDeleted)
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton.icon(
                    onPressed: () => _editNote(note),
                    icon: Icon(Icons.edit, color: Colors.green),
                    label: Text("Edit",
                        style: GoogleFonts.poppins(color: Colors.green)),
                  ),
                  TextButton.icon(
                    onPressed: () => _deleteNote(note),
                    icon: Icon(Icons.delete, color: Colors.red),
                    label: Text("Delete",
                        style: GoogleFonts.poppins(color: Colors.red)),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.eventName,
            style: GoogleFonts.poppins(
              color: Colors.white,
            )),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.home),
          onPressed: () {
            Navigator.popUntil(context, (route) => route.isFirst);
          },
        ),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: fetchEventDetails,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildEventDetailsCard(),
                    const SizedBox(height: 12),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: notes.length,
                      itemBuilder: (context, index) {
                        return _buildNoteCard(notes[index]);
                      },
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}

class AudioPlayerWidget extends StatefulWidget {
  final String audioUrl;
  const AudioPlayerWidget({required this.audioUrl, Key? key}) : super(key: key);

  @override
  _AudioPlayerWidgetState createState() => _AudioPlayerWidgetState();
}

class _AudioPlayerWidgetState extends State<AudioPlayerWidget> {
  late AudioPlayer _player;
  bool isPlaying = false;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    _player.onPlayerStateChanged.listen((state) {
      setState(() {
        isPlaying = (state == PlayerState.playing);
      });
    });
  }

  Future<void> _togglePlayPause() async {
    if (isPlaying) {
      await _player.pause();
      setState(() {
        isPlaying = false;
      });
    } else {
      setState(() {
        isLoading = true;
      });
      await _player.play(UrlSource(widget.audioUrl));
      setState(() {
        isLoading = false;
        isPlaying = true;
      });
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: isLoading
          ? SizedBox(
              height: 24,
              width: 24,
              child: CircularProgressIndicator(
                strokeWidth: 2,
              ),
            )
          : Icon(isPlaying ? Icons.pause : Icons.play_arrow,
              color: Colors.green),
      onPressed: _togglePlayPause,
    );
  }
}

class EditNotePage extends StatefulWidget {
  final Map<String, dynamic> note;
  EditNotePage({required this.note});

  @override
  _EditNotePageState createState() => _EditNotePageState();
}

class _EditNotePageState extends State<EditNotePage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController noteTitleCtrl;
  late TextEditingController startTimeCtrl;
  late TextEditingController endTimeCtrl;
  late TextEditingController noteContentCtrl;
  late TextEditingController audioCtrl;
  bool _isSubmitting = false;

  final CloudinaryPublic _cloudinary =
      CloudinaryPublic('dzlhl3e6j', 'unsigned_preset', cache: false);
  final FlutterSoundRecorder _audioRecorder = FlutterSoundRecorder();
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isRecordingAudio = false;
  String? _audioPath;

  @override
  void initState() {
    super.initState();
    noteTitleCtrl = TextEditingController(text: widget.note['title'] ?? '');
    String sessionTime = widget.note['session_time'] ?? "";
    List<String> times = sessionTime.split(" - ");
    startTimeCtrl =
        TextEditingController(text: times.isNotEmpty ? times[0] : '');
    endTimeCtrl = TextEditingController(text: times.length > 1 ? times[1] : '');
    noteContentCtrl = TextEditingController(text: widget.note['notes'] ?? '');
    audioCtrl = TextEditingController(text: widget.note['audio'] ?? '');
    _initRecorder();
  }

  Future<void> _initRecorder() async {
    await _audioRecorder.openRecorder();
    await Permission.microphone.request();
  }

  @override
  void dispose() {
    noteTitleCtrl.dispose();
    startTimeCtrl.dispose();
    endTimeCtrl.dispose();
    noteContentCtrl.dispose();
    audioCtrl.dispose();
    _audioRecorder.closeRecorder();
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _startAudioRecording() async {
    try {
      setState(() {
        audioCtrl.text = "";
      });
      Directory appDir = await getApplicationDocumentsDirectory();
      String filePath =
          '${appDir.path}/audio_${DateTime.now().millisecondsSinceEpoch}.aac';
      await _audioRecorder.startRecorder(
          toFile: filePath, codec: Codec.aacADTS);
      setState(() {
        _isRecordingAudio = true;
        _audioPath = filePath;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to start recording: $e')));
    }
  }

  Future<void> _stopAudioRecording() async {
    try {
      String? path = await _audioRecorder.stopRecorder();
      setState(() {
        _isRecordingAudio = false;
        _audioPath = path;
      });
      await _uploadAudio();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to stop recording: $e')));
    }
  }

  Future<void> _uploadAudio() async {
    if (_audioPath != null) {
      try {
        final uploaded = await _cloudinary.uploadFile(
          CloudinaryFile.fromFile(_audioPath!,
              resourceType: CloudinaryResourceType.Auto),
        );
        setState(() {
          audioCtrl.text = uploaded.secureUrl;
        });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Audio uploaded successfully"),
            backgroundColor: Colors.green));
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Error uploading audio: $e"),
            backgroundColor: Colors.red));
      }
    }
  }

  void _deleteRecording() {
    setState(() {
      _audioPath = null;
      audioCtrl.text = "";
    });
  }

  Future<void> _submitForm() async {
    setState(() {
      _isSubmitting = true;
    });
    final Map<String, dynamic> body = {
      'id': widget.note['note_id'].toString(),
      'note_title': noteTitleCtrl.text,
      'start_time': startTimeCtrl.text,
      'end_time': endTimeCtrl.text,
      'note_content': noteContentCtrl.text,
      'audio': audioCtrl.text,
      'status': widget.note['note_status'],
    };
    try {
      final response = await http.post(
        Uri.parse(
            'https://demo.yelbee.com/events/manage_notes.php?action=update'),
        headers: {"Content-Type": "application/json"},
        body: json.encode(body),
      );
      final data = jsonDecode(response.body);
      if (data['success'] == true) {
        Navigator.pop(context, true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['error'] ?? 'Failed to update note')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally {
      setState(() {
        _isSubmitting = false;
      });
    }
  }

  Future<void> _pickTime(TextEditingController controller) async {
    TimeOfDay? picked =
        await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (picked != null) {
      setState(() {
        controller.text = picked.format(context);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            Text("Edit Note", style: GoogleFonts.poppins(color: Colors.white)),
        centerTitle: true,
      ),
      backgroundColor: const Color(0xFFD1E8FF),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.07),
                    blurRadius: 8,
                    offset: const Offset(0, 4))
              ],
            ),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Text("Editing Note",
                      style: GoogleFonts.lato(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF0B1957))),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: noteTitleCtrl,
                    decoration: InputDecoration(
                      labelText: "Note Title",
                      prefixIcon:
                          Icon(Icons.title, color: const Color(0xFF0B1957)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: startTimeCtrl,
                          readOnly: true,
                          decoration: InputDecoration(
                            labelText: "Start Time",
                            prefixIcon: Icon(Icons.access_time,
                                color: const Color(0xFF0B1957)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                          onTap: () => _pickTime(startTimeCtrl),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextFormField(
                          controller: endTimeCtrl,
                          readOnly: true,
                          decoration: InputDecoration(
                            labelText: "End Time",
                            prefixIcon: Icon(Icons.access_time,
                                color: const Color(0xFF0B1957)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                          onTap: () => _pickTime(endTimeCtrl),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: noteContentCtrl,
                    maxLines: 3,
                    decoration: InputDecoration(
                      labelText: "Note Content",
                      prefixIcon:
                          Icon(Icons.note, color: const Color(0xFF0B1957)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: audioCtrl,
                    readOnly: true,
                    decoration: InputDecoration(
                      labelText: "Audio Note URL",
                      prefixIcon: Icon(Icons.audiotrack,
                          color: const Color(0xFF0B1957)),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _isRecordingAudio
                          ? Expanded(
                              child: ElevatedButton.icon(
                                onPressed: _stopAudioRecording,
                                icon: Icon(Icons.stop, color: Colors.white),
                                label: Text("Stop Recording",
                                    style:
                                        GoogleFonts.lato(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.red),
                              ),
                            )
                          : Expanded(
                              child: ElevatedButton.icon(
                                onPressed: _startAudioRecording,
                                icon: Icon(Icons.mic, color: Colors.white),
                                label: Text("Record Audio",
                                    style:
                                        GoogleFonts.lato(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF0B1957)),
                              ),
                            ),
                      const SizedBox(width: 12),
                      if (_audioPath != null)
                        IconButton(
                          tooltip: "Play Recorded Audio",
                          icon: Icon(Icons.play_arrow, color: Colors.green),
                          onPressed: () async {
                            await _audioPlayer
                                .play(DeviceFileSource(_audioPath!));
                          },
                        ),
                      if (_audioPath != null)
                        IconButton(
                          tooltip: "Delete Recorded Audio",
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: _deleteRecording,
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isSubmitting ? null : _submitForm,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF0B1957),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      child: _isSubmitting
                          ? CircularProgressIndicator(
                              valueColor:
                                  AlwaysStoppedAnimation<Color>(Colors.white))
                          : Text('Save',
                              style: GoogleFonts.lato(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
