// // schedule_alarm_page.dart
// import 'dart:convert';
// import 'dart:io';
// import 'package:app_settings/app_settings.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:intl/intl.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'noti_service.dart';

// class NotificationPage extends StatefulWidget {
//   final String eventId;
//   final String eventName;
//   final DateTime eventStart;

//   const NotificationPage({
//     Key? key,
//     required this.eventId,
//     required this.eventName,
//     required this.eventStart,
//   }) : super(key: key);

//   @override
//   State<NotificationPage> createState() => _NotificationPageState();
// }

// class _NotificationPageState extends State<NotificationPage> {
//   Future<Map<String, dynamic>>? _futureEvent;
//   DateTime? _scheduledAlarm;

//   @override
//   void initState() {
//     super.initState();
//     _futureEvent = fetchEventById(widget.eventId);
//     _loadScheduledAlarm();
//     WidgetsBinding.instance
//         .addPostFrameCallback((_) => _showAlarmPermissionDialog());
//   }

//   Future<void> _loadScheduledAlarm() async {
//     final prefs = await SharedPreferences.getInstance();
//     final savedAlarm = prefs.getString('scheduledAlarm_${widget.eventId}');
//     if (savedAlarm != null) {
//       setState(() {
//         _scheduledAlarm = DateTime.tryParse(savedAlarm);
//       });
//     }
//   }

//   Future<void> _saveScheduledAlarm(DateTime alarmTime) async {
//     final prefs = await SharedPreferences.getInstance();
//     await prefs.setString(
//         'scheduledAlarm_${widget.eventId}', alarmTime.toIso8601String());
//   }

//   Future<Map<String, dynamic>> fetchEventById(String id) async {
//     final url = Uri.parse('https://demo.yelbee.com/events/events.php');
//     try {
//       final response = await http.get(url);
//       if (response.statusCode == 200) {
//         final data = json.decode(response.body);
//         if (data is List) {
//           final event = data.firstWhere(
//             (e) => e['id'].toString() == id,
//             orElse: () => {},
//           );
//           if (event.isEmpty) {
//             throw Exception("Event with id $id not found.");
//           }
//           return Map<String, dynamic>.from(event);
//         } else {
//           throw Exception("Unexpected data format");
//         }
//       } else {
//         throw Exception("HTTP error: ${response.statusCode}");
//       }
//     } on SocketException {
//       throw Exception("No internet connection available.");
//     } catch (e) {
//       throw Exception("Failed to load event: $e");
//     }
//   }

//   DateTime getEventStartDateTime(String eventTimeString) {
//     try {
//       final firstTimeString = eventTimeString.split('-').first.trim();
//       final parsedTime = DateFormat.jm().parse(firstTimeString);
//       return DateTime(
//         widget.eventStart.year,
//         widget.eventStart.month,
//         widget.eventStart.day,
//         parsedTime.hour,
//         parsedTime.minute,
//       );
//     } catch (e) {
//       debugPrint("Error parsing event start time: $e");
//     }
//     return widget.eventStart;
//   }

//   String formatDateTime(DateTime dt) =>
//       DateFormat('dd-MM-yyyy hh:mm a').format(dt);
//   String formatDate(DateTime dt) => DateFormat('dd-MM-yyyy').format(dt);
//   String formatTime(DateTime dt) => DateFormat('hh:mm a').format(dt);

//   Future<void> _pickCustomDateTime() async {
//     final DateTime initialDate = widget.eventStart.isAfter(DateTime.now())
//         ? widget.eventStart
//         : DateTime.now();
//     final DateTime? pickedDate = await showDatePicker(
//       context: context,
//       initialDate: initialDate,
//       firstDate: DateTime.now(),
//       lastDate: DateTime.now().add(const Duration(days: 365)),
//     );
//     if (pickedDate == null) return;
//     final TimeOfDay? pickedTime = await showTimePicker(
//       context: context,
//       initialTime: TimeOfDay.now(),
//     );
//     if (pickedTime == null) return;
//     final DateTime customDateTime = DateTime(
//       pickedDate.year,
//       pickedDate.month,
//       pickedDate.day,
//       pickedTime.hour,
//       pickedTime.minute,
//     );
//     if (customDateTime.isBefore(DateTime.now())) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//           content: Text('Please select a future date and time.'),
//         ),
//       );
//       return;
//     }
//     NotiService.scheduleNotification(
//       title: widget.eventName,
//       body: 'Alarm set for ${formatDateTime(customDateTime)}',
//       payload: 'custom',
//       scheduledDate: customDateTime,
//     );
//     await _saveScheduledAlarm(customDateTime);
//     setState(() {
//       _scheduledAlarm = customDateTime;
//     });
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text('Alarm scheduled for ${formatDateTime(customDateTime)}'),
//       ),
//     );
//   }

//   void _showAlarmPermissionDialog() {
//     showDialog(
//       context: context,
//       builder: (context) {
//         return AlertDialog(
//           title: const Text('Enable Alarms & Reminders'),
//           content: const Text(
//             'Exact alarms may be restricted. Please enable alarms and reminders in settings if you experience issues.',
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: const Text('Cancel'),
//             ),
//             TextButton(
//               onPressed: () {
//                 Navigator.of(context).pop();
//                 AppSettings.openAppSettings();
//               },
//               child: const Text('Settings'),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Alarm for "${widget.eventName}"'),
//         backgroundColor: const Color(0xFF0B1957),
//         centerTitle: true,
//       ),
//       backgroundColor: Colors.grey[200],
//       body: FutureBuilder<Map<String, dynamic>>(
//         future: _futureEvent,
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return const Center(child: CircularProgressIndicator());
//           } else if (snapshot.hasError) {
//             return Center(
//               child: Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: Text(
//                   snapshot.error.toString(),
//                   style: const TextStyle(fontSize: 16, color: Colors.red),
//                   textAlign: TextAlign.center,
//                 ),
//               ),
//             );
//           } else {
//             final eventDetails = snapshot.data!;
//             final String dbEventTime = eventDetails['time'] ?? '';
//             final eventStartTime = getEventStartDateTime(dbEventTime);
//             return SingleChildScrollView(
//               child: Padding(
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
//                 child: Card(
//                   elevation: 4,
//                   shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(16)),
//                   child: Padding(
//                     padding: const EdgeInsets.all(20),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.stretch,
//                       children: [
//                         Text(
//                           widget.eventName,
//                           style: const TextStyle(
//                             fontSize: 24,
//                             fontWeight: FontWeight.bold,
//                             color: Color(0xFF0B1957),
//                           ),
//                           textAlign: TextAlign.center,
//                         ),
//                         const SizedBox(height: 12),
//                         ListTile(
//                           leading: const Icon(Icons.calendar_today,
//                               color: Color(0xFF0B1957)),
//                           title: Text(
//                             'Date: ${formatDate(widget.eventStart)}',
//                             style: const TextStyle(fontSize: 16),
//                           ),
//                         ),
//                         ListTile(
//                           leading: const Icon(Icons.access_time,
//                               color: Color(0xFF0B1957)),
//                           title: Text(
//                             'Event Time: $dbEventTime',
//                             style: const TextStyle(fontSize: 16),
//                           ),
//                         ),
//                         const Divider(thickness: 1.5),
//                         const SizedBox(height: 8),
//                         const Center(
//                           child: Text(
//                             'Alarm Settings',
//                             style: TextStyle(
//                                 fontSize: 20, fontWeight: FontWeight.w600),
//                           ),
//                         ),
//                         const SizedBox(height: 8),
//                         if (_scheduledAlarm != null)
//                           ListTile(
//                             leading:
//                                 const Icon(Icons.alarm_on, color: Colors.green),
//                             title: Text(
//                               'Alarm is set for: ${formatDateTime(_scheduledAlarm!)}',
//                               style: const TextStyle(fontSize: 16),
//                             ),
//                           )
//                         else
//                           ListTile(
//                             leading: const Icon(Icons.alarm_add,
//                                 color: Colors.deepOrange),
//                             title: const Text('No Alarm Set'),
//                             subtitle: const Text('Tap to set an alarm'),
//                             trailing: const Icon(Icons.arrow_forward_ios),
//                             onTap: _pickCustomDateTime,
//                           ),
//                         const Divider(),
//                         if (_scheduledAlarm != null)
//                           ListTile(
//                             leading: const Icon(Icons.edit,
//                                 color: Colors.deepOrange),
//                             title: const Text('Change Alarm'),
//                             trailing: const Icon(Icons.arrow_forward_ios),
//                             onTap: _pickCustomDateTime,
//                           ),
//                         const SizedBox(height: 8),
//                         Center(
//                           child: Text(
//                             'Current Time: ${formatDateTime(DateTime.now())}',
//                             style: const TextStyle(
//                                 fontSize: 14, color: Colors.grey),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             );
//           }
//         },
//       ),
//     );
//   }
// }
