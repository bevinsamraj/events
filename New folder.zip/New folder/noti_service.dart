// // noti_service.dart
// import 'package:flutter/material.dart';
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:timezone/timezone.dart' as tz;
// import 'package:timezone/data/latest_all.dart' as tz;

// class NotiService {
//   static final FlutterLocalNotificationsPlugin _notificationsPlugin =
//       FlutterLocalNotificationsPlugin();

//   static Future<void> initialize() async {
//     tz.initializeTimeZones();
//     const AndroidInitializationSettings initializationSettingsAndroid =
//         AndroidInitializationSettings('@mipmap/ic_launcher');

//     const InitializationSettings initializationSettings =
//         InitializationSettings(android: initializationSettingsAndroid);

//     await _notificationsPlugin.initialize(
//       initializationSettings,
//       onDidReceiveNotificationResponse: (NotificationResponse response) async {
//         debugPrint('Notification payload: ${response.payload}');
//       },
//     );
//   }

//   static Future<void> scheduleNotification({
//     int id = 0,
//     String? title,
//     String? body,
//     String? payload,
//     required DateTime scheduledDate,
//   }) async {
//     tz.TZDateTime tzScheduledDate = tz.TZDateTime.from(scheduledDate, tz.local);
//     final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
//     if (tzScheduledDate.isBefore(now)) {
//       tzScheduledDate = tzScheduledDate.add(const Duration(days: 1));
//       debugPrint(
//           "Scheduled time was in the past. Adjusted to: $tzScheduledDate");
//     }
//     try {
//       await _notificationsPlugin.zonedSchedule(
//         id,
//         title,
//         body,
//         tzScheduledDate,
//         NotificationDetails(
//           android: AndroidNotificationDetails(
//             'scheduled_channel',
//             'Scheduled Notifications',
//             channelDescription: 'Channel for scheduled notifications',
//             icon: '@mipmap/ic_launcher',
//             importance: Importance.max,
//             priority: Priority.high,
//             fullScreenIntent: true,
//             sound: RawResourceAndroidNotificationSound('alarm'),
//           ),
//         ),
//         uiLocalNotificationDateInterpretation:
//             UILocalNotificationDateInterpretation.absoluteTime,
//         androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
//         payload: payload,
//       );
//     } catch (e) {
//       debugPrint("Error scheduling notification: $e");
//       rethrow;
//     }
//   }
// }
