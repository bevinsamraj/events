// // add_alarm_page.dart
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:flutter_local_notifications/flutter_local_notifications.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:timezone/data/latest.dart' as tzData;
// import 'package:timezone/timezone.dart' as tz;

// class AddAlarmPage extends StatefulWidget {
//   final Map<String, dynamic> event;
//   const AddAlarmPage({super.key, required this.event});

//   @override
//   State<AddAlarmPage> createState() => _AddAlarmPageState();
// }

// class _AddAlarmPageState extends State<AddAlarmPage> {
//   TimeOfDay? _selectedTime;
//   late FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin;

//   @override
//   void initState() {
//     super.initState();
//     // Initialize timezone data before using tz.local.
//     tzData.initializeTimeZones();
//     _flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

//     const AndroidInitializationSettings androidSettings =
//         AndroidInitializationSettings('@mipmap/ic_launcher');
//     final DarwinInitializationSettings iosSettings =
//         DarwinInitializationSettings();
//     final InitializationSettings initSettings = InitializationSettings(
//       android: androidSettings,
//       iOS: iosSettings,
//     );
//     _flutterLocalNotificationsPlugin.initialize(initSettings);
//   }

//   Future<void> _pickTime() async {
//     final now = TimeOfDay.now();
//     final picked = await showTimePicker(context: context, initialTime: now);
//     if (picked != null) {
//       setState(() {
//         _selectedTime = picked;
//       });
//     }
//   }

//   Future<void> _scheduleAlarm() async {
//     if (_selectedTime == null) return;
//     final now = DateTime.now();
//     final scheduledDate = DateTime(
//       now.year,
//       now.month,
//       now.day,
//       _selectedTime!.hour,
//       _selectedTime!.minute,
//     );
//     final alarmDate = scheduledDate.isBefore(now)
//         ? scheduledDate.add(const Duration(days: 1))
//         : scheduledDate;
//     // tz.initializeTimeZones() has been called so tz.local is now available.
//     final tzAlarmDate = tz.TZDateTime.from(alarmDate, tz.local);
//     final payload = jsonEncode(widget.event);

//     const AndroidNotificationDetails androidDetails =
//         AndroidNotificationDetails(
//       'alarm_channel',
//       'Alarm Notifications',
//       channelDescription: 'Channel for Alarm notifications',
//       importance: Importance.max,
//       priority: Priority.high,
//       playSound: true,
//       fullScreenIntent: true,
//     );
//     const DarwinNotificationDetails iosDetails = DarwinNotificationDetails();
//     const NotificationDetails platformDetails =
//         NotificationDetails(android: androidDetails, iOS: iosDetails);

//     await _flutterLocalNotificationsPlugin.zonedSchedule(
//       0,
//       'Alarm for ${widget.event['event_name'] ?? 'Event'}',
//       'It is time for your event.',
//       tzAlarmDate,
//       platformDetails,
//       payload: payload,
//       androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
//       uiLocalNotificationDateInterpretation:
//           UILocalNotificationDateInterpretation.absoluteTime,
//     );

//     if (mounted) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(
//           content: Text('Alarm set for ${_selectedTime!.format(context)}'),
//           backgroundColor: Colors.blue,
//         ),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final eventTitle = widget.event['event_name'] ?? 'Event';
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         backgroundColor: Colors.blue,
//         centerTitle: true,
//         title: Text('Set Alarm', style: GoogleFonts.poppins()),
//       ),
//       body: Center(
//         child: Card(
//           elevation: 6,
//           margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
//           shape:
//               RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//           child: Padding(
//             padding: const EdgeInsets.all(24),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 Icon(Icons.alarm, size: 100, color: Colors.blue),
//                 const SizedBox(height: 16),
//                 Text(
//                   eventTitle,
//                   style: GoogleFonts.poppins(
//                     fontSize: 28,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.blue,
//                   ),
//                   textAlign: TextAlign.center,
//                 ),
//                 const SizedBox(height: 16),
//                 Text(
//                   _selectedTime == null
//                       ? 'No time selected'
//                       : 'Alarm Time: ${_selectedTime!.format(context)}',
//                   style: GoogleFonts.poppins(
//                     fontSize: 20,
//                     color: Colors.blue.shade700,
//                   ),
//                 ),
//                 const SizedBox(height: 24),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     ElevatedButton.icon(
//                       onPressed: _pickTime,
//                       icon: const Icon(Icons.access_time),
//                       label: Text('Pick Time', style: GoogleFonts.poppins()),
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.blue,
//                         foregroundColor: Colors.white,
//                         padding: const EdgeInsets.symmetric(
//                             horizontal: 16, vertical: 12),
//                         shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(8)),
//                         textStyle: const TextStyle(fontSize: 18),
//                       ),
//                     ),
//                     ElevatedButton.icon(
//                       onPressed: _scheduleAlarm,
//                       icon: const Icon(Icons.alarm),
//                       label: Text('Set Alarm', style: GoogleFonts.poppins()),
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.blue,
//                         foregroundColor: Colors.white,
//                         padding: const EdgeInsets.symmetric(
//                             horizontal: 16, vertical: 12),
//                         shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(8)),
//                         textStyle: const TextStyle(fontSize: 18),
//                       ),
//                     ),
//                   ],
//                 )
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
