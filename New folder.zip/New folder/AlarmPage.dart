// alarm_page.dart
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class AlarmPage extends StatefulWidget {
  final Map<String, dynamic> event;
  const AlarmPage({Key? key, required this.event}) : super(key: key);

  @override
  State<AlarmPage> createState() => _AlarmPageState();
}

class _AlarmPageState extends State<AlarmPage> {
  late final AudioPlayer _audioPlayer;

  @override
  void initState() {
    super.initState();
    // Enable immersive full-screen mode to overlay on all apps
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _audioPlayer = AudioPlayer();
    _startAlarm();
  }

  Future<void> _startAlarm() async {
    await _audioPlayer.setReleaseMode(ReleaseMode.loop);
    // Ensure that your asset (e.g. assets/alarm.mp3) is declared in pubspec.yaml.
    await _audioPlayer.play(AssetSource('alarm.mp3'));
  }

  Future<void> _stopAlarm() async {
    await _audioPlayer.stop();
    // Restore system UI before exiting
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    if (mounted) {
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final eventTitle = widget.event['event_name'] ?? 'Event';
    final eventTime = widget.event['time'] ?? '';
    return Scaffold(
      backgroundColor: Colors.red.shade100,
      body: SafeArea(
        child: Container(
          width: double.infinity,
          height: double.infinity,
          color: Colors.red.shade100,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.alarm, size: 120, color: Colors.red),
              const SizedBox(height: 20),
              Text(
                "Alarm for $eventTitle",
                style: GoogleFonts.poppins(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.red.shade900,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              Text(
                "Starts at: $eventTime",
                style: GoogleFonts.poppins(
                  fontSize: 24,
                  color: Colors.red.shade700,
                ),
              ),
              const SizedBox(height: 40),
              ElevatedButton.icon(
                onPressed: _stopAlarm,
                icon: const Icon(Icons.stop),
                label: const Text("Stop Alarm"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red.shade700,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  textStyle: const TextStyle(fontSize: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
