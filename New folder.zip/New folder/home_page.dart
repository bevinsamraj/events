// home_page.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:events/manage_events.dart';
import 'package:flutter/material.dart';
import 'package:flutter_advanced_drawer/flutter_advanced_drawer.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import 'reports_page.dart';
import 'find_contact_page.dart';
import 'event_detail_page.dart';
import 'add_note_page.dart';
import 'manage_notes_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _advancedDrawerController = AdvancedDrawerController();
  late Future<List<Map<String, dynamic>>> _futureEvents;
  late List<DateTime> _dates;
  bool _isMonthView = false;

  late List<DateTime> _months;
  int _selectedMonthIndex = DateTime.now().month - 1;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _dates =
        List.generate(7, (i) => DateTime(now.year, now.month, now.day + i));
    _months = List.generate(12, (index) => DateTime(now.year, index + 1, 1));
    _futureEvents = _fetchEvents();
  }

  Future<List<Map<String, dynamic>>> _fetchEvents() async {
    final url = Uri.parse('https://demo.yelbee.com/events/events.php');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data is List) {
          final events = data
              .map((dynamic item) {
                final map = item as Map<String, dynamic>;
                if (map['tags'] is String) {
                  try {
                    map['tags'] = json.decode(map['tags']) as List;
                  } catch (_) {
                    map['tags'] = <String>[];
                  }
                }
                return map;
              })
              .where((map) => map['status'] != 'off')
              .toList();
          return events;
        } else {
          throw Exception("Unexpected data format");
        }
      } else {
        throw Exception("HTTP error: ${response.statusCode}");
      }
    } on SocketException {
      throw Exception(
          "No internet connection available. Please check your WiFi and Internet connectivity.");
    } catch (e) {
      throw Exception("Failed to load events: $e");
    }
  }

  Future<bool> _handleDeleteEvent(
      BuildContext context, Map<String, dynamic> event) async {
    final eventId = event['id']?.toString() ?? '';
    final eventName = event['event_name'] ?? 'Unknown';
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Event'),
        content: Text('Do you want to set status=off for "$eventName"?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('No')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Yes')),
        ],
      ),
    );
    if (confirmed == true) {
      final deleteUrl = Uri.parse(
          'https://demo.yelbee.com/events/manage_events.php?action=delete&id=$eventId');
      try {
        final response = await http.delete(deleteUrl);
        if (response.statusCode == 200) {
          final body = json.decode(response.body);
          if (body['success'] == true) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Event "$eventName" set to off.')),
              );
            }
            return true;
          } else {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(body['error'] ?? 'Failed to delete.')),
              );
            }
          }
        } else {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                  content:
                      Text('HTTP ${response.statusCode} - delete failed.')),
            );
          }
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: $e')),
          );
        }
      }
    }
    return false;
  }

  Future<void> _handleEditEvent(
      BuildContext context, Map<String, dynamic> event) async {
    final eventName = event['event_name'] ?? 'Unknown';
    final id = event['id']?.toString() ?? '';
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Edit Event'),
        content: Text('Do you want to edit "$eventName"?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('No')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Yes')),
        ],
      ),
    );
    if (confirmed == true) {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => ManageEventsPage(initialEditId: id)));
    }
  }

  void _handleMenuButtonPressed() {
    _advancedDrawerController.showDrawer();
  }

  @override
  Widget build(BuildContext context) {
    return AdvancedDrawer(
      controller: _advancedDrawerController,
      animationCurve: Curves.easeInOut,
      animationDuration: const Duration(milliseconds: 300),
      drawer: SafeArea(
        child: Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const CircleAvatar(
                radius: 40,
                backgroundColor: Colors.white,
                child: Icon(Icons.person, size: 50, color: Color(0xFF0B1957)),
              ),
              const SizedBox(height: 20),
              Text(
                "Welcome!",
                style: GoogleFonts.poppins(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF0B1957)),
              ),
              const SizedBox(height: 40),
              ListTile(
                leading: const Icon(Icons.report, color: Color(0xFF0B1957)),
                title: const Text('Reports'),
                onTap: () {
                  _advancedDrawerController.hideDrawer();
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const ReportsPage()));
                },
              ),
              ListTile(
                leading:
                    const Icon(Icons.contact_phone, color: Color(0xFF0B1957)),
                title: const Text('Find Contact'),
                onTap: () {
                  _advancedDrawerController.hideDrawer();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const FindContactPage()));
                },
              ),
              ListTile(
                leading:
                    const Icon(Icons.construction, color: Color(0xFF0B1957)),
                title: const Text('Manage Events'),
                onTap: () {
                  _advancedDrawerController.hideDrawer();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const ManageEventsPage()));
                },
              ),
              ListTile(
                leading: const Icon(Icons.note, color: Color(0xFF0B1957)),
                title: const Text('Manage Notes'),
                onTap: () {
                  _advancedDrawerController.hideDrawer();
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => ManageNotesPage()));
                },
              ),
              const Spacer(),
              ListTile(
                leading: const Icon(Icons.logout, color: Color(0xFF0B1957)),
                title: const Text('Logout'),
                onTap: () {
                  _advancedDrawerController.hideDrawer();
                },
              ),
            ],
          ),
        ),
      ),
      child: Scaffold(
        backgroundColor: const Color(0xFFD1E8FF),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.menu,
                            size: 30, color: Colors.black),
                        onPressed: _handleMenuButtonPressed,
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              "SCHEDULE",
                              style: GoogleFonts.poppins(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Events",
                              style: GoogleFonts.poppins(
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                  color: const Color(0xFF0B1957)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                if (!_isMonthView) ...[
                  SizedBox(
                    height: 100,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _dates.length,
                      itemBuilder: (context, index) {
                        final date = _dates[index];
                        final isSelected = index == _selectedIndex;
                        return GestureDetector(
                          onTap: () => setState(() => _selectedIndex = index),
                          child: Container(
                            width: 70,
                            margin: const EdgeInsets.symmetric(horizontal: 6),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? const Color(0xFF0B1957)
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 4,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    '${date.day}',
                                    style: GoogleFonts.poppins(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: isSelected
                                          ? Colors.white
                                          : const Color(0xFF0B1957),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    _shortWeekDayName(date),
                                    style: GoogleFonts.poppins(
                                      fontSize: 14,
                                      color: isSelected
                                          ? Colors.white70
                                          : Colors.grey[700],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16.0, vertical: 8.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            "${_longWeekDayName(_dates[_selectedIndex])}, ${_dates[_selectedIndex].day}",
                            style: GoogleFonts.poppins(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: const Color(0xFF0B1957)),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.calendar_view_month,
                              size: 30, color: Colors.black),
                          onPressed: () {
                            setState(() {
                              _isMonthView = true;
                            });
                          },
                          tooltip: "Switch to Month View",
                        ),
                      ],
                    ),
                  ),
                  FutureBuilder<List<Map<String, dynamic>>>(
                    future: _futureEvents,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Padding(
                          padding: EdgeInsets.all(16),
                          child: CircularProgressIndicator(),
                        );
                      } else if (snapshot.hasError) {
                        String errorMessage = snapshot.error.toString();
                        if (errorMessage
                            .contains("No internet connection available")) {
                          errorMessage =
                              "No internet connection available. Please check your WiFi and Internet connectivity.";
                        }
                        return Padding(
                          padding: const EdgeInsets.all(16),
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  errorMessage,
                                  style: GoogleFonts.poppins(
                                      fontSize: 16,
                                      color: Colors.red,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 20),
                                ElevatedButton(
                                  onPressed: () {
                                    setState(() {
                                      _futureEvents = _fetchEvents();
                                    });
                                  },
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF0B1957)),
                                  child: Text("Retry",
                                      style: GoogleFonts.poppins(
                                          fontSize: 16, color: Colors.white)),
                                )
                              ],
                            ),
                          ),
                        );
                      } else {
                        final selectedDate = _dates[_selectedIndex];
                        final events = snapshot.data ?? [];
                        final selectedEvents = events.where((e) {
                          final startDateStr = e['start_date'] ?? '';
                          final endDateStr = e['end_date'] ?? '';
                          if (startDateStr.isEmpty || endDateStr.isEmpty)
                            return false;
                          try {
                            final startDate = DateTime.parse(startDateStr);
                            final endDate = DateTime.parse(endDateStr);
                            return (selectedDate.compareTo(startDate) >= 0 &&
                                selectedDate.compareTo(endDate) <= 0);
                          } catch (_) {
                            return false;
                          }
                        }).toList();

                        if (selectedEvents.isEmpty) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            child: Text(
                              "No events for ${_formatDateDisplay(selectedDate)}.",
                              style: GoogleFonts.poppins(
                                  fontSize: 16, color: Colors.black54),
                            ),
                          );
                        } else {
                          return ListView.builder(
                            itemCount: selectedEvents.length,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemBuilder: (context, i) {
                              final e = selectedEvents[i];
                              return _buildDismissibleEventTile(e);
                            },
                          );
                        }
                      }
                    },
                  ),
                ] else ...[
                  SizedBox(
                    height: 80,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _months.length,
                      itemBuilder: (context, index) {
                        final month = _months[index];
                        final isSelected = index == _selectedMonthIndex;
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedMonthIndex = index;
                            });
                          },
                          child: Container(
                            width: 80,
                            margin: const EdgeInsets.symmetric(horizontal: 8),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? const Color(0xFF0B1957)
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.05),
                                  blurRadius: 4,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Center(
                              child: Text(
                                _shortMonthName(month.month),
                                style: GoogleFonts.poppins(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: isSelected
                                      ? Colors.white
                                      : const Color(0xFF0B1957),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16.0, vertical: 8.0),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            "${_shortMonthName(_months[_selectedMonthIndex].month)} ${_months[_selectedMonthIndex].year}",
                            style: GoogleFonts.poppins(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: const Color(0xFF0B1957)),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.calendar_view_day,
                              size: 30, color: Colors.black),
                          onPressed: () {
                            setState(() {
                              _isMonthView = false;
                            });
                          },
                          tooltip: "Switch to Day View",
                        ),
                      ],
                    ),
                  ),
                  FutureBuilder<List<Map<String, dynamic>>>(
                    future: _futureEvents,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Padding(
                          padding: EdgeInsets.all(16),
                          child: CircularProgressIndicator(),
                        );
                      } else if (snapshot.hasError) {
                        String errorMessage = snapshot.error.toString();
                        if (errorMessage
                            .contains("No internet connection available")) {
                          errorMessage =
                              "No internet connection available. Please check your WiFi and Internet connectivity.";
                        }
                        return Padding(
                          padding: const EdgeInsets.all(16),
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  errorMessage,
                                  style: GoogleFonts.poppins(
                                      fontSize: 16,
                                      color: Colors.red,
                                      fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 20),
                                ElevatedButton(
                                  onPressed: () {
                                    setState(() {
                                      _futureEvents = _fetchEvents();
                                    });
                                  },
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF0B1957)),
                                  child: Text("Retry",
                                      style: GoogleFonts.poppins(
                                          fontSize: 16, color: Colors.white)),
                                )
                              ],
                            ),
                          ),
                        );
                      } else {
                        final events = snapshot.data ?? [];
                        final selectedMonth = _months[_selectedMonthIndex];
                        // Filter events for the selected month
                        final monthEvents = events.where((e) {
                          final startDateStr = e['start_date'] ?? '';
                          if (startDateStr.isEmpty) return false;
                          try {
                            final startDate = DateTime.parse(startDateStr);
                            return startDate.month == selectedMonth.month &&
                                startDate.year == selectedMonth.year;
                          } catch (_) {
                            return false;
                          }
                        }).toList();

                        // Sort events in ascending order by their start date
                        monthEvents.sort((a, b) {
                          try {
                            final aDate = DateTime.parse(a['start_date']);
                            final bDate = DateTime.parse(b['start_date']);
                            return aDate.compareTo(bDate);
                          } catch (_) {
                            return 0;
                          }
                        });

                        if (monthEvents.isEmpty) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            child: Text(
                              "No events for ${_shortMonthName(selectedMonth.month)} ${selectedMonth.year}.",
                              style: GoogleFonts.poppins(
                                  fontSize: 16, color: Colors.black54),
                            ),
                          );
                        } else {
                          return ListView.builder(
                            itemCount: monthEvents.length,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index) {
                              final e = monthEvents[index];
                              return _buildDismissibleEventTile(e);
                            },
                          );
                        }
                      }
                    },
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDismissibleEventTile(Map<String, dynamic> e) {
    final id = e['id']?.toString() ?? '${e.hashCode}';
    return Dismissible(
      key: ValueKey(id),
      direction: DismissDirection.horizontal,
      background: _swipeBackground(
          color: Colors.green,
          icon: Icons.edit,
          alignment: Alignment.centerLeft,
          text: "Edit"),
      secondaryBackground: _swipeBackground(
          color: Colors.red,
          icon: Icons.delete,
          alignment: Alignment.centerRight,
          text: "Delete"),
      confirmDismiss: (direction) async {
        if (direction == DismissDirection.startToEnd) {
          await _handleEditEvent(context, e);
          return false;
        } else {
          final result = await _handleDeleteEvent(context, e);
          return result;
        }
      },
      child: _buildEventTile(e),
    );
  }

  Widget _swipeBackground(
      {required Color color,
      required IconData icon,
      required Alignment alignment,
      required String text}) {
    return Container(
      alignment: alignment,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      color: color,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white),
          const SizedBox(width: 8),
          Text(text,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildEventTile(Map<String, dynamic> e) {
    final time = e['time'] ?? '';
    final title = e['event_name'] ?? '';
    final place = e['venue'] ?? '';
    final contact = e['contact_number'] ?? '';
    final type = (e['event_type'] ?? 'national').toLowerCase();
    final tags = (e['tags'] is List) ? e['tags'] as List : <String>[];

    final bool isNational = (type == 'national');
    final dotColor = isNational ? Colors.green : Colors.orange;
    final labelText = isNational ? "NATIONAL" : "INTERNATIONAL";
    final labelBgColor =
        isNational ? Colors.green.shade100 : Colors.orange.shade100;
    final labelTextColor =
        isNational ? Colors.green.shade800 : Colors.orange.shade800;

    final startDateStr = e['start_date'] ?? '';
    DateTime? startDate;
    if (startDateStr.isNotEmpty) {
      try {
        startDate = DateTime.parse(startDateStr);
        if (e['time'] != null && (e['time'] as String).isNotEmpty) {
          final timeParts = (e['time'] as String).split(':');
          if (timeParts.length >= 2) {
            final hour = int.parse(timeParts[0]);
            final minute = int.parse(timeParts[1]);
            startDate = DateTime(
                startDate.year, startDate.month, startDate.day, hour, minute);
          }
        }
      } catch (_) {}
    }

    final endDateStr = e['end_date'] ?? '';
    DateTime? endDate;
    if (endDateStr.isNotEmpty) {
      try {
        endDate = DateTime.parse(endDateStr);
      } catch (_) {}
    }

    return Stack(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: GestureDetector(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => EventDetailPage(event: e)));
            },
            child: Container(
              padding: const EdgeInsets.only(bottom: 40),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  Container(
                    width: 60,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    alignment: Alignment.center,
                    child: RotatedBox(
                      quarterTurns: 3,
                      child: Text(
                        time,
                        style: GoogleFonts.lato(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF0B1957)),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 16, 4, 16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: labelBgColor,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                        color: dotColor,
                                        shape: BoxShape.circle)),
                                const SizedBox(width: 6),
                                Text(labelText,
                                    style: GoogleFonts.lato(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: labelTextColor)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(title,
                              style: GoogleFonts.lato(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: const Color(0xFF0B1957))),
                          const SizedBox(height: 6),
                          Text(place,
                              style: GoogleFonts.lato(
                                  fontSize: 14, color: Colors.black87)),
                          const SizedBox(height: 4),
                          Text(contact,
                              style: GoogleFonts.lato(
                                  fontSize: 14, color: Colors.black54)),
                          const SizedBox(height: 8),
                          if (tags.isNotEmpty)
                            Wrap(
                              spacing: 8,
                              runSpacing: 4,
                              children: tags.map<Widget>((tag) {
                                return Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: Colors.grey[300],
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Text("#$tag",
                                      style: GoogleFonts.lato(
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold,
                                          color: const Color(0xFF0B1957))),
                                );
                              }).toList(),
                            ),
                        ],
                      ),
                    ),
                  ),
                  if (startDate != null)
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        width: 80,
                        decoration: BoxDecoration(
                          color: const Color(0xFF0B1957),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            if (endDate != null && startDate.day != endDate.day)
                              Text('${startDate.day} - ${endDate.day}',
                                  style: GoogleFonts.lato(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white))
                            else
                              Text('${startDate.day}',
                                  style: GoogleFonts.lato(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white)),
                            Text(_shortMonthName(startDate.month),
                                style: GoogleFonts.lato(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white)),
                            Text('${startDate.year}',
                                style: GoogleFonts.lato(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w400,
                                    color: Colors.white70)),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
        if (startDate != null)
          Positioned(
            right: 24,
            bottom: 24,
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: GestureDetector(
                onTap: () {
                  final eventId = e['id']?.toString() ?? '';
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AddNotePage(eventId: eventId),
                    ),
                  );
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF0B1957),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 4,
                        offset: const Offset(2, 2),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.all(8),
                  child: const Icon(Icons.add, color: Colors.white, size: 20),
                ),
              ),
            ),
          ),
      ],
    );
  }

  String _formatDateDisplay(DateTime date) {
    final dd = date.day < 10 ? '0${date.day}' : '${date.day}';
    final mm = date.month < 10 ? '0${date.month}' : '${date.month}';
    final yyyy = date.year;
    return "$dd-$mm-$yyyy";
  }

  String _shortWeekDayName(DateTime date) {
    const names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return names[date.weekday - 1];
  }

  String _longWeekDayName(DateTime date) {
    const fullNames = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday'
    ];
    return fullNames[date.weekday - 1];
  }

  String _shortMonthName(int month) {
    const monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return monthNames[month - 1];
  }
}
